# Aerovision Inference Package

航空器图像推理 Package，提供以下功能：

- **机型分类**：使用YOLOv8-cls进行机型识别
- **航司识别**：使用YOLOv8-cls进行航空公司识别
- **注册号OCR识别**：支持本地PaddleOCR和外部API两种模式
- **图像质量评估**：使用纯CV算法进行质量评估（清晰度、曝光、构图、噪点、色彩）

## 特性

- ✅ **完全解耦**：与v1-server完全解耦，可独立使用
- ✅ **纯接口参数**：所有配置通过初始化参数传入，无需环境变量
- ✅ **双模式OCR**：支持本地PaddleOCR和外部API两种部署方式
- ✅ **纯CV质量评估**：无需VLM，快速且低成本
- ✅ **灵活配置**：支持自定义权重和阈值

## 安装

### 使用 pip

```bash
pip install -r requirements.txt
```

### 依赖要求

- Python >= 3.8
- PyTorch >= 1.10
- CUDA >= 11.0（GPU支持，可选）
- PaddlePaddle >= 2.6.2（本地OCR模式需要）
- OpenCV >= 4.8.0

## 快速开始

### 基本使用

```python
from aerovision_inference import (
    AircraftClassifier,
    AirlineClassifier,
    RegistrationOCR,
    QualityAssessor
)

# 1. 机型分类
classifier = AircraftClassifier(
    model_path="path/to/aircraft_model.pt",
    device="cuda",  # 或 "cpu"
    image_size=640
)
result = classifier.predict("path/to/image.jpg", top_k=5)
print(result["top1"]["class"])  # "A320"

# 2. 航司识别
airline_clf = AirlineClassifier(
    model_path="path/to/airline_model.pt",
    device="cuda"
)
result = airline_clf.predict("path/to/image.jpg")
print(result["top1"]["class"])  # "CEA"

# 3. 注册号OCR（本地模式）
ocr = RegistrationOCR(mode="local", lang="ch", use_angle_cls=True)
result = ocr.recognize("path/to/image.jpg")
print(result["registration"])  # "B-1234"

# 4. 注册号OCR（API模式）
ocr_api = RegistrationOCR(
    mode="api",
    api_url="http://localhost:8000/v2/models/ocr/infer"
)
result = ocr_api.recognize("path/to/image.jpg")

# 5. 质量评估（纯CV）
assessor = QualityAssessor(
    sharpness_weight=0.3,
    exposure_weight=0.2,
    composition_weight=0.15,
    noise_weight=0.2,
    color_weight=0.15,
    pass_threshold=0.6
)
result = assessor.assess("path/to/image.jpg")
print(result["score"])  # 0.85
print(result["pass"])  # True
```

### 使用示例

查看 `example_usage.py` 获取7个完整示例：
1. 机型分类
2. 航司分类
3. OCR识别（本地模式）
4. OCR识别（API模式）
5. 质量评估（纯CV）
6. 完整推理流程
7. 配置管理

## API 文档

### 1. AircraftClassifier - 机型分类器

#### 初始化

```python
AircraftClassifier(
    model_path: Union[str, Path],  # 模型文件路径（必需）
    device: str = "cuda",          # 计算设备（cuda/cpu）
    image_size: int = 640          # 图像尺寸
)
```

#### 方法

##### predict()

```python
predict(
    image: Union[str, Path, bytes, "Image.Image"],  # 图像输入
    top_k: int = None                                # 返回top-k结果
) -> Dict[str, Any]
```

**图像输入支持：**
- 文件路径（str或Path）
- 字节流（bytes）
- PIL Image对象
- base64编码字符串

**返回格式：**

```python
{
    "predictions": [
        {"class": "A320", "confidence": 0.85},
        {"class": "B738", "confidence": 0.10},
        ...
    ],
    "top1": {"class": "A320", "confidence": 0.85},
    "top_k": 5
}
```

---

### 2. AirlineClassifier - 航司分类器

#### 初始化

```python
AirlineClassifier(
    model_path: Union[str, Path],  # 模型文件路径（必需）
    device: str = "cuda",          # 计算设备（cuda/cpu）
    image_size: int = 640          # 图像尺寸
)
```

#### 方法

##### predict()

```python
predict(
    image: Union[str, Path, bytes, "Image.Image"],  # 图像输入
    top_k: int = None                                # 返回top-k结果
) -> Dict[str, Any]
```

**返回格式：**

```python
{
    "predictions": [
        {"class": "CEA", "confidence": 0.85},
        {"class": "CCA", "confidence": 0.10},
        ...
    ],
    "top1": {"class": "CEA", "confidence": 0.85},
    "top_k": 5
}
```

---

### 3. RegistrationOCR - 注册号OCR识别

#### 初始化

**本地模式（使用本地PaddleOCR）：**

```python
RegistrationOCR(
    mode="local",              # 本地模式
    lang: str = "ch",          # OCR语言
    use_angle_cls: bool = True, # 是否使用角度分类
    enabled: bool = True       # 是否启用
)
```

**API模式（调用外部OCR服务）：**

```python
RegistrationOCR(
    mode="api",                                    # API模式
    api_url: str = "http://localhost:8000/...",   # OCR服务地址
    timeout: int = 30,                            # 请求超时时间
    enabled: bool = True                          # 是否启用
)
```

#### 方法

##### recognize()

```python
recognize(
    image: Union[str, Path, bytes, "Image.Image"],  # 图像输入
    output_yolo_txt: Optional[Union[str, Path]] = None  # YOLO格式输出文件路径（可选）
) -> Dict[str, Any]
```

**返回格式：**

```python
{
    "registration": "B-1234",        # 识别的注册号（置信度最高）
    "confidence": 0.95,              # 注册号识别置信度
    "raw_text": "B-1234",            # OCR原始识别文本
    "all_matches": [                 # 所有匹配的注册号列表
        {"text": "B-1234", "confidence": 0.95}
    ],
    "yolo_boxes": [                  # YOLO格式的目标框信息
        {
            "class_id": 0,
            "x_center": 0.5,         # 归一化坐标
            "y_center": 0.3,
            "width": 0.2,
            "height": 0.1,
            "text": "B-1234",
            "confidence": 0.95
        }
    ]
}
```

**注册号格式：**

支持国际民航组织（ICAO）格式的注册号，使用正则表达式匹配：
- `B-1234` - 中国
- `N1234` - 美国
- `G-XXXX` - 英国
- 等其他格式

---

### 4. QualityAssessor - 质量评估器（纯CV实现）

#### 初始化

```python
QualityAssessor(
    sharpness_weight: float = 0.3,      # 清晰度权重
    exposure_weight: float = 0.2,        # 曝光权重
    composition_weight: float = 0.15,    # 构图权重
    noise_weight: float = 0.2,           # 噪点权重
    color_weight: float = 0.15,          # 色彩权重
    pass_threshold: float = 0.6          # 通过阈值
)
```

#### 方法

##### assess()

综合评估图片质量（评估所有指标）。

```python
assess(
    image: Union[str, Path, np.ndarray, "Image.Image"]
) -> Dict[str, Any]
```

**返回格式：**

```python
{
    "success": True,
    "pass": True,               # 是否通过质量检查
    "score": 0.85,              # 总分（0-1）
    "details": {
        "sharpness": 0.90,      # 清晰度（Laplacian方差）
        "exposure": 0.80,       # 曝光（LAB色彩空间）
        "composition": 0.85,    # 构图（三分法则）
        "noise": 0.88,          # 噪点（高斯滤波）
        "color": 0.82           # 色彩（HSV饱和度+白平衡）
    }
}
```

##### quick_assess()

快速评估（仅评估清晰度）。

```python
quick_assess(
    image: Union[str, Path, np.ndarray, "Image.Image"]
) -> Dict[str, Any]
```

**返回格式：**

```python
{
    "pass": True,           # 是否清晰
    "sharpness": 0.90       # 清晰度分数
}
```

**评估指标说明：**

| 指标 | 方法 | 评分标准 |
|------|------|----------|
| 清晰度 | Laplacian方差 | variance < 100: 模糊<br>variance > 1000: 清晰 |
| 曝光 | LAB亮度分析 | 理想亮度: 100-150<br>惩罚过曝/欠曝 |
| 构图 | 三分法则 | 主体位置越接近三分点分数越高 |
| 噪点 | 高斯滤波 | noise_level < 5: 好<br>noise_level > 20: 差 |
| 色彩 | HSV饱和度+白平衡 | 理想饱和度: 60-150<br>RGB通道差异检测白平衡 |

---

## 配置管理

### 推荐方式：使用配置字典

```python
# 配置字典
config = {
    # 模型路径配置
    "aircraft_model_path": "/path/to/aircraft_model.pt",
    "airline_model_path": "/path/to/airline_model.pt",

    # 设备配置
    "device": "cuda",  # 或 "cpu"

    # OCR配置
    "ocr": {
        "mode": "api",
        "api_url": "http://localhost:8000/v2/models/ocr/infer",
        "timeout": 30
    },

    # 质量评估配置
    "quality": {
        "sharpness_weight": 0.3,
        "exposure_weight": 0.2,
        "composition_weight": 0.15,
        "noise_weight": 0.2,
        "color_weight": 0.15,
        "pass_threshold": 0.6
    }
}

# 使用配置初始化
aircraft_cls = AircraftClassifier(
    model_path=config["aircraft_model_path"],
    device=config["device"]
)

airline_cls = AirlineClassifier(
    model_path=config["airline_model_path"],
    device=config["device"]
)

ocr = RegistrationOCR(**config["ocr"])
quality_assessor = QualityAssessor(**config["quality"])
```

### 环境变量（可选）

虽然支持使用环境变量，但不推荐。推荐使用配置字典或直接传入参数。

```bash
# .env 文件（不推荐）
DEVICE=cuda
OCR_API_URL=http://localhost:8000/v2/models/ocr/infer
```

---

## 开发

### 运行示例

```bash
# 修改example_usage.py中的路径后运行
python example_usage.py
```

### 运行测试

```bash
# 运行所有测试
pytest

# 运行特定测试
pytest tests/test_aircraft_classifier.py

# 运行测试并显示覆盖率
pytest --cov=.

# 详细输出
pytest -v
```

---

## 部署

### OCR服务部署

**API模式需要部署PaddleX OCR服务：**

```bash
# 使用PaddleX部署OCR服务
paddlex --serve --model_name=PP-OCRv4 --port=8000
```

---

## 重构说明

### v2.0 主要变更

1. **质量评估重构**：
   - ❌ 移除：VLM（GLM-4.6V）质量评估
   - ✅ 新增：纯CV质量评估（快速、低成本）
   - ✅ 新增：5个评估指标（清晰度、曝光、构图、噪点、色彩）
   - ✅ 新增：可配置权重和阈值

2. **OCR重构**：
   - ✅ 新增：API模式支持（外部OCR服务）
   - ✅ 保留：本地PaddleOCR模式
   - ✅ 新增：模式切换参数

3. **配置重构**：
   - ❌ 移除：环境变量依赖
   - ✅ 新增：纯接口参数配置
   - ✅ 新增：配置字典支持

4. **解耦**：
   - ✅ 完全移除对`Aerovision_V1.training.src.vlm.glm_client`的依赖
   - ✅ 可独立运行，无需v1-server

### 迁移指南

**从v1.x迁移到v2.0：**

```python
# v1.x（旧版本）
assessor = QualityAssessor(
    api_key="your_api_key",
    model="glm-4.6v"
)
result = assessor.assess(image)
# 旧返回格式：{"clarity": 0.85, "block": 0.17, ...}

# v2.0（新版本）
assessor = QualityAssessor(
    sharpness_weight=0.3,
    exposure_weight=0.2,
    pass_threshold=0.6
)
result = assessor.assess(image)
# 新返回格式：{"success": True, "pass": True, "score": 0.85, "details": {...}}
```

---

## 许可证

MIT License

---

## 贡献

欢迎提交 Issue 和 Pull Request。
