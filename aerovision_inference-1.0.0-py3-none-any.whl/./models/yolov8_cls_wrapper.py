"""
YOLOv8分类器封装
"""

from ultralytics import YOLO
import torch
import logging
from typing import Dict, List, Any, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Fix for PyTorch 2.6 weights_only default change
original_torch_load = torch.load

def patched_torch_load(f, *args, weights_only=False, **kwargs):
    """Patched torch.load that sets weights_only=False for YOLO models"""
    return original_torch_load(f, *args, weights_only=weights_only, **kwargs)

torch.load = patched_torch_load


class YOLOv8Classifier:
    """YOLOv8-cls分类器封装"""

    def __init__(self, model_path: str, device: str = "cuda"):
        """
        初始化YOLOv8分类器

        Args:
            model_path: 模型文件路径
            device: 计算设备（cuda/cpu）
        """
        self.model_path = model_path
        self.device = device

        # 加载模型
        try:
            self.model = YOLO(model_path)
            self.model.to(device)
            logger.info(f"YOLOv8-cls model loaded from {model_path}")
        except Exception as e:
            logger.error(f"Failed to load YOLOv8-cls model: {e}")
            raise

        # 获取类别名称
        self.class_names = self._load_class_names()

    def _load_class_names(self) -> Dict[int, str]:
        """
        加载类别名称映射

        Returns:
            Dict[int, str]: 类别ID到名称的映射
        """
        if hasattr(self.model, "names"):
            return self.model.names
        return {}

    def predict(
        self,
        image,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        预测图片类别

        Args:
            image: PIL Image对象
            top_k: 返回前k个预测结果

        Returns:
            Dict: 包含所有预测结果的字典
        """
        try:
            logger.info(f"Starting prediction, top_k: {top_k}")

            # 推理
            results = self.model.predict(image, verbose=False)

            if not results or len(results) == 0:
                logger.error("No results from model.predict()")
                raise ValueError("No prediction results returned")

            # 获取预测结果（分类模型返回probs）
            probs = results[0].probs
            if probs is None:
                logger.error("Probs is None in result")
                raise ValueError("No probabilities in prediction result")

            # 获取所有类别的置信度并排序
            probs_data = probs.data
            num_classes = len(probs_data)
            actual_top_k = min(top_k, num_classes)

            # 获取topk索引
            topk_indices = torch.topk(probs_data, actual_top_k).indices

            # 构建预测结果列表
            predictions = []
            for idx in topk_indices:
                class_id = idx.item()
                confidence = probs.data[class_id].item()
                class_name = self.class_names.get(class_id, f"Class_{class_id}")
                predictions.append({
                    "class": class_name,
                    "confidence": float(confidence)
                })

            # 按置信度降序排序（topk已经排序，但为了保险）
            predictions.sort(key=lambda x: x["confidence"], reverse=True)

            # 返回完整结果
            result = {
                "predictions": predictions,
                "top1": predictions[0] if predictions else None,
                "top_k": actual_top_k
            }

            logger.info(f"Prediction completed, top_k: {actual_top_k}")
            return result

        except Exception as e:
            logger.error(f"Prediction error: {e}", exc_info=True)
            raise

    def get_class_names(self) -> Dict[int, str]:
        """
        获取类别名称映射

        Returns:
            Dict[int, str]: 类别ID到名称的映射
        """
        return self.class_names

    def get_info(self) -> Dict[str, Any]:
        """
        获取模型信息

        Returns:
            Dict[str, Any]: 模型信息字典
        """
        return {
            "model_type": "yolov8-cls",
            "model_path": self.model_path,
            "device": self.device,
            "num_classes": len(self.class_names),
            "classes": [{"id": k, "name": v} for k, v in self.class_names.items()]
        }
