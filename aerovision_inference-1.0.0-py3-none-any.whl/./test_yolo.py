#!/usr/bin/env python3
"""测试YOLO格式的OCR输出"""
import sys
import os
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from registration_ocr import RegistrationOCR

def test_yolo_format():
    # 测试OCR
    try:
        ocr = RegistrationOCR(lang='ch', use_angle_cls=True)
        print('OCR initialized successfully')

        test_image = '/home/wlx/Aerovision-V1-inference/test_data/test_image.jpg'
        result = ocr.recognize(test_image)
        print('Recognition result:')
        print(f'  Registration: {result.get("registration", "")}')
        print(f'  Confidence: {result.get("confidence", 0.0)}')
        print(f'  Raw text: {result.get("raw_text", "")}')
        print(f'  Number of YOLO boxes: {len(result.get("yolo_boxes", []))}')

        # 检查YOLO格式
        for i, box in enumerate(result.get('yolo_boxes', [])):
            print(f'  Box {i}: class_id={box["class_id"]}, x_center={box["x_center"]}, y_center={box["y_center"]}, width={box["width"]}, height={box["height"]}')

            # 验证值范围
            assert 0 <= box['x_center'] <= 1, f"x_center out of range: {box['x_center']}"
            assert 0 <= box['y_center'] <= 1, f"y_center out of range: {box['y_center']}"
            assert 0 <= box['width'] <= 1, f"width out of range: {box['width']}"
            assert 0 <= box['height'] <= 1, f"height out of range: {box['height']}"

        print('\\n✓ YOLO format validation passed')

        # 测试保存到文件
        output_path = '/home/wlx/Aerovision-V1-inference/test_data/output.txt'
        result = ocr.recognize(test_image, output_yolo_txt=output_path)

        # 读取输出文件
        if os.path.exists(output_path):
            with open(output_path, 'r') as f:
                content = f.read()
                print(f'\\n✓ YOLO format saved to {output_path}:')
                print(content)

                # 验证文件格式
                lines = content.strip().split('\\n')
                for line in lines:
                    parts = line.strip().split()
                    assert len(parts) == 5, f"Invalid YOLO format: {line}"
                    class_id = int(parts[0])
                    x_center = float(parts[1])
                    y_center = float(parts[2])
                    width = float(parts[3])
                    height = float(parts[4])

                    assert 0 <= class_id, f"Invalid class_id: {class_id}"
                    assert 0 <= x_center <= 1, f"Invalid x_center: {x_center}"
                    assert 0 <= y_center <= 1, f"Invalid y_center: {y_center}"
                    assert 0 <= width <= 1, f"Invalid width: {width}"
                    assert 0 <= height <= 1, f"Invalid height: {height}"

                print(f'✓ YOLO file format validation passed')
        else:
            print(f'✗ Output file not created')
            return False

        print('\\n✓ All tests passed!')
        return True

    except Exception as e:
        print(f'✗ Error: {e}')
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_yolo_format()
    sys.exit(0 if success else 1)
