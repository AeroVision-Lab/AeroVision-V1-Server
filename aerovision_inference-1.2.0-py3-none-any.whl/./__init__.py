"""
Aerovision Inference Package

提供航空器图像识别功能：
- 机型分类（AircraftClassifier）
- 航司识别（AirlineClassifier）
- 注册号识别（RegistrationOCR）- 支持混合OCR策略（Qwen3-VL-Plus + PaddleOCR）
- 质量评估（QualityAssessor）
- 向量数据库（VectorDatabase）
- 新类别发现（NewClassDiscovery）
"""

__version__ = "1.2.0"
__all__ = [
    "AircraftClassifier",
    "AirlineClassifier",
    "RegistrationOCR",
    "QualityAssessor",
    "VectorDatabase",
    "NewClassDiscovery",
    "VectorRecord",
    "SimilarityResult",
]

def __getattr__(name: str):
    """延迟导入实现"""
    if name == "AircraftClassifier":
        from aircraft_classifier import AircraftClassifier
        return AircraftClassifier
    if name == "AirlineClassifier":
        from airline_classifier import AirlineClassifier
        return AirlineClassifier
    if name == "RegistrationOCR":
        from registration_ocr import RegistrationOCR
        return RegistrationOCR
    if name == "QualityAssessor":
        from quality_assessor import QualityAssessor
        return QualityAssessor
    if name == "VectorDatabase":
        from vector_database import VectorDatabase
        return VectorDatabase
    if name == "NewClassDiscovery":
        from vector_database import NewClassDiscovery
        return NewClassDiscovery
    if name == "VectorRecord":
        from vector_database import VectorRecord
        return VectorRecord
    if name == "SimilarityResult":
        from vector_database import SimilarityResult
        return SimilarityResult
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
