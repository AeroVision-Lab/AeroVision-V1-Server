"""
航司分类器
使用YOLOv8-cls模型进行航司识别
"""

import logging
from typing import Dict, Any, Union
from pathlib import Path

from models.yolov8_cls_wrapper import YOLOv8Classifier
from utils.image_processing import load_image, resize_image

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AirlineClassifier:
    """航司分类器 - 使用YOLOv8-cls模型"""

    def __init__(
        self,
        model_path: Union[str, Path],
        device: str = "cuda",
        image_size: int = 640
    ):
        """
        初始化航司分类器

        Args:
            model_path: 模型文件路径（必需）
            device: 计算设备（cuda/cpu），默认cuda
            image_size: 图像尺寸，默认640
        """
        self.model_path = model_path
        self.device = device
        self.image_size = image_size

        # 初始化分类器
        self.classifier = YOLOv8Classifier(
            model_path=str(model_path),
            device=device
        )

        logger.info(f"AirlineClassifier initialized: {model_path}, device={device}, image_size={image_size}")

    def predict(
        self,
        image: Union[str, Path, bytes, "Image.Image"],
        top_k: int = None
    ) -> Dict[str, Any]:
        """
        预测航司

        Args:
            image: 图像输入，支持：
                - 文件路径（str或Path）
                - 字节流（bytes）
                - PIL Image对象
                - base64编码字符串
            top_k: 返回top-k预测结果，如果为None则从config中获取

        Returns:
            Dict: 预测结果，包含所有类别和置信度
                {
                    "predictions": [
                        {"class": "CEA", "confidence": 0.85},
                        {"class": "CCA", "confidence": 0.10},
                        ...
                    ],
                    "top1": {"class": "CEA", "confidence": 0.85},
                    "top_k": 5
                }
        """
        # 加载图像
        pil_image = load_image(image)

        # 调整图像尺寸
        pil_image = resize_image(pil_image, self.image_size)

        # 预测
        result = self.classifier.predict(pil_image, top_k=top_k)

        return result

    def get_class_names(self):
        """
        获取类别名称

        Returns:
            类别名称映射
        """
        return self.classifier.get_class_names()

    def get_model_info(self) -> Dict[str, Any]:
        """
        获取模型信息

        Returns:
            Dict: 模型信息
        """
        return {
            "type": "airline_classifier",
            "model_path": self.model_path,
            "device": self.device,
            "image_size": self.image_size,
            **self.classifier.get_info()
        }
