"""
阿里云百炼 Qwen3-VL OCR 客户端
用于飞机注册号 OCR 识别
"""

import os
import io
import base64
import json
import logging
import re
from typing import Dict, Any, Optional, Union
from pathlib import Path
from PIL import Image

import requests

logger = logging.getLogger(__name__)


class DashScopeError(Exception):
    """DashScope API 错误"""
    pass


class DashScopeOCRClient:
    """阿里云百炼 Qwen3-VL OCR 客户端"""

    # 注册号正则表达式：匹配国际民航组织（ICAO）格式的注册号
    REGISTRATION_PATTERN = re.compile(
        r"\b([A-Z]{1,2})[- ]?([A-HJ-NP-Z0-9][A-HJ-NP-Z0-9]{0,4})\b"
    )

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "qwen3-vl-flash",
        timeout: int = 30
    ):
        """
        初始化 DashScope OCR 客户端

        Args:
            api_key: DashScope API Key，如果不提供则从环境变量 DASHSCOPE_API_KEY 读取
            model: 模型名称，可选: qwen3-vl-flash
            timeout: 请求超时时间（秒）

        Raises:
            DashScopeError: 如果 API Key 不存在
        """
        self.api_key = api_key or os.getenv("DASHSCOPE_API_KEY")

        if not self.api_key:
            raise DashScopeError(
                "DASHSCOPE_API_KEY not found in environment variables. "
                "Please set the DASHSCOPE_API_KEY environment variable."
            )

        self.model = model
        self.timeout = timeout
        self.api_base = "https://dashscope.aliyuncs.com"

        logger.info(f"DashScope OCR client initialized (model={model})")

    def _encode_image(self, image: Union[str, Path, bytes, Image.Image]) -> str:
        """
        编码图片为 base64 URL

        Args:
            image: 图像输入

        Returns:
            str: base64 编码的图片 URL
        """
        # 加载图片
        if isinstance(image, (str, Path)):
            pil_image = Image.open(image)
        elif isinstance(image, bytes):
            pil_image = Image.open(io.BytesIO(image))
        else:
            pil_image = image

        # 转换为 RGB
        if pil_image.mode != "RGB":
            pil_image = pil_image.convert("RGB")

        # 编码为 base64
        img_byte_arr = io.BytesIO()
        pil_image.save(img_byte_arr, format="JPEG")
        img_bytes = img_byte_arr.getvalue()
        base64_str = base64.b64encode(img_bytes).decode("utf-8")

        return f"data:image/jpeg;base64,{base64_str}"

    def _get_system_prompt(self) -> str:
        """
        获取系统提示词

        Returns:
            str: 系统提示词
        """
        return """你是一个专业的航空器注册号OCR识别专家。你的任务是从提供的飞机注册号区域图片中准确识别注册号文字。

识别要求：
1. 仔细观察图片中的字母和数字，注意区分相似的字符（如O和0、I和1等）
2. 注册号格式通常为：B-XXXX（中国）、N-XXXX（美国）、G-XXXX（英国）等
3. 给出识别结果的置信度（0-1之间的数值，1表示完全确定），置信度必须客观准确，确保与实际识别准确率相匹配
4. 如果图片模糊或无法识别，请给出最可能的识别结果并标注低置信度

输出格式要求：
请严格按照以下JSON格式输出，不要包含任何其他内容：
{
    "registration": "B-1234",
    "confidence": 0.6,
    "reasoning": "识别理由简述"
}

示例：
- 对于清晰的注册号图片：{"registration": "B-1234", "confidence": 0.9, "reasoning": "字符清晰可辨"}
- 对于模糊的注册号图片：{"registration": "B-1X34", "confidence": 0.5, "reasoning": "第三位字符模糊，可能是2或X"}"""

    def _get_user_prompt(self) -> str:
        """
        获取用户提示词

        Returns:
            str: 用户提示词
        """
        return """请识别这张图片中的飞机注册号。

请仔细观察图片中的字母和数字，准确识别注册号，并给出客观的置信度和识别理由。注意区分相似的字符。"""

    def recognize(
        self,
        image: Union[str, Path, bytes, Image.Image]
    ) -> Dict[str, Any]:
        """
        识别注册号

        Args:
            image: 图像输入

        Returns:
            Dict[str, Any]: 识别结果
                {
                    "registration": "B-1234",
                    "confidence": 0.95,
                    "raw_text": "B-1234",
                    "all_matches": [],
                    "yolo_boxes": []
                }

        Raises:
            DashScopeError: API 调用失败
        """
        # 编码图片
        image_url = self._encode_image(image)

        # 构建请求（使用兼容模式 API）
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        # 兼容模式 API 格式（支持更多模型，包括 qwen3.5-plus）
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": self._get_system_prompt()
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": image_url
                            }
                        },
                        {
                            "type": "text",
                            "text": self._get_user_prompt()
                        }
                    ]
                }
            ],
            "max_tokens": 512,
            "temperature": 0.3,
            "top_p": 0.7
        }

        # 发送请求
        try:
            url = f"{self.api_base}/compatible-mode/v1/chat/completions"

            logger.debug(f"Calling DashScope API: {url}")
            logger.debug(f"Model: {self.model}")

            response = requests.post(url, json=payload, headers=headers, timeout=self.timeout)

            # 如果失败，打印详细信息
            if response.status_code != 200:
                logger.error(f"API request failed with status {response.status_code}")
                logger.error(f"Response: {response.text}")

            response.raise_for_status()

            result = response.json()

            # 解析响应（兼容模式格式）
            content = result["choices"][0]["message"]["content"]

            # 解析 JSON
            parsed = self._parse_response(content)

            return {
                "registration": parsed.get("registration", ""),
                "confidence": float(parsed.get("confidence", 0.0)),
                "raw_text": parsed.get("registration", ""),
                "all_matches": [],
                "yolo_boxes": []
            }

        except requests.exceptions.RequestException as e:
            logger.error(f"DashScope API request failed: {e}")
            raise DashScopeError(f"API request failed: {e}")
        except (KeyError, IndexError) as e:
            logger.error(f"Failed to parse API response: {e}")
            raise DashScopeError(f"Invalid API response: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            raise DashScopeError(f"JSON parse error: {e}")

    def _parse_response(self, content: str) -> Dict[str, Any]:
        """
        解析响应内容

        Args:
            content: API 返回的内容

        Returns:
            Dict[str, Any]: 解析后的结果

        Raises:
            DashScopeError: 解析失败
        """
        # 尝试直接解析
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            pass

        # 尝试提取 JSON 代码块
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', content, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass

        # 尝试提取花括号内的内容
        brace_match = re.search(r'\{.*\}', content, re.DOTALL)
        if brace_match:
            try:
                return json.loads(brace_match.group(0))
            except json.JSONDecodeError:
                pass

        # 如果都失败，返回默认值
        logger.warning(f"Failed to parse response, using default values: {content[:100]}")
        return {
            "registration": "",
            "confidence": 0.0,
            "reasoning": "Failed to parse model response"
        }

    def get_info(self) -> Dict[str, Any]:
        """
        获取客户端信息

        Returns:
            Dict[str, Any]: 客户端信息
        """
        return {
            "type": "dashscope",
            "model": self.model,
            "api_base": self.api_base,
            "timeout": self.timeout
        }
