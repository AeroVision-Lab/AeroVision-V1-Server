"""
增强预测器
集成向量数据库、相似度搜索和新类别发现
"""

import logging
from typing import Dict, Any, List, Optional, Union
from pathlib import Path
from dataclasses import dataclass

import numpy as np
from PIL import Image

from predictor import ModelPredictor
from vector_database import VectorDatabase, VectorRecord, SimilarityResult, NewClassDiscovery

logger = logging.getLogger(__name__)


@dataclass
class EnhancedPredictionResult:
    """增强预测结果"""
    aircraft: Dict[str, Any]
    airline: Dict[str, Any]
    similar_records: List[SimilarityResult]
    is_new_class: bool = False
    new_class_score: Optional[float] = None
    query_embeddings: Optional[Dict[str, np.ndarray]] = None


class EnhancedPredictor:
    """
    增强预测器
    集成向量数据库、相似度搜索和新类别发现
    """

    def __init__(
        self,
        config: Dict[str, Any],
        vector_db: Optional[VectorDatabase] = None,
        new_class_discovery: Optional[NewClassDiscovery] = None,
        enable_vector_search: bool = True,
        enable_new_class_detection: bool = True,
        top_k_similar: int = 5
    ):
        """
        初始化增强预测器

        Args:
            config: 模型配置
            vector_db: 向量数据库实例
            new_class_discovery: 新类别发现实例
            enable_vector_search: 是否启用向量搜索
            enable_new_class_detection: 是否启用新类别检测
            top_k_similar: 返回的相似记录数
        """
        self.config = config
        self.predictor = ModelPredictor(config)

        self.vector_db = vector_db
        self.new_class_discovery = new_class_discovery

        self.enable_vector_search = enable_vector_search
        self.enable_new_class_detection = enable_new_class_detection
        self.top_k_similar = top_k_similar

        logger.info(
            f"EnhancedPredictor initialized "
            f"(vector_search={enable_vector_search}, "
            f"new_class_detection={enable_new_class_detection})"
        )

    def predict(
        self,
        image_path: str,
        record_id: Optional[str] = None,
        save_to_db: bool = True
    ) -> EnhancedPredictionResult:
        """
        预测并检索相似记录

        Args:
            image_path: 图片路径
            record_id: 记录 ID（用于保存到数据库）
            save_to_db: 是否保存到数据库

        Returns:
            增强预测结果
        """
        # 基础预测
        result = self.predictor.predict(image_path)

        # 获取特征向量
        aircraft_emb = self.predictor.aircraft_model.embed(
            image_path,
            imgsz=self.predictor.image_size,
            device=self.predictor.device,
            verbose=False
        )[0]

        airline_emb = self.predictor.airline_model.embed(
            image_path,
            imgsz=self.predictor.image_size,
            device=self.predictor.device,
            verbose=False
        )[0]

        # 转换为 numpy 数组
        if hasattr(aircraft_emb, 'cpu'):
            aircraft_emb = aircraft_emb.cpu().numpy()
        if hasattr(airline_emb, 'cpu'):
            airline_emb = airline_emb.cpu().numpy()

        aircraft_emb = np.array(aircraft_emb).flatten()
        airline_emb = np.array(airline_emb).flatten()

        # 相似度搜索
        similar_records = []
        if self.enable_vector_search and self.vector_db is not None:
            similar_records = self.vector_db.search_similar(
                aircraft_embedding=aircraft_emb,
                airline_embedding=airline_emb,
                top_k=self.top_k_similar
            )

        # 新类别检测
        is_new_class = False
        new_class_score = None
        if self.enable_new_class_detection and self.new_class_discovery is not None:
            # 单样本新类别检测
            is_new_class = self._is_new_class(
                aircraft_emb, airline_emb, similar_records
            )

        # 保存到数据库
        if save_to_db and self.vector_db is not None:
            self._save_to_db(
                image_path=image_path,
                record_id=record_id,
                aircraft_emb=aircraft_emb,
                airline_emb=airline_emb,
                result=result
            )

        return EnhancedPredictionResult(
            aircraft=result["aircraft"],
            airline=result["airline"],
            similar_records=similar_records,
            is_new_class=is_new_class,
            new_class_score=new_class_score,
            query_embeddings={
                "aircraft": aircraft_emb,
                "airline": airline_emb
            }
        )

    def _is_new_class(
        self,
        aircraft_emb: np.ndarray,
        airline_emb: np.ndarray,
        similar_records: List[SimilarityResult],
        similarity_threshold: float = 0.3
    ) -> bool:
        """
        判断是否为新类别

        Args:
            aircraft_emb: 机型特征向量
            airline_emb: 航司特征向量
            similar_records: 相似记录列表
            similarity_threshold: 相似度阈值

        Returns:
            是否为新类别
        """
        if len(similar_records) == 0:
            return True

        # 如果最相似的记录相似度低于阈值，认为是新类别
        top_similarity = similar_records[0].similarity
        return top_similarity < similarity_threshold

    def _save_to_db(
        self,
        image_path: str,
        record_id: Optional[str],
        aircraft_emb: np.ndarray,
        airline_emb: np.ndarray,
        result: Dict[str, Any]
    ):
        """
        保存到向量数据库

        Args:
            image_path: 图片路径
            record_id: 记录 ID
            aircraft_emb: 机型特征向量
            airline_emb: 航司特征向量
            result: 预测结果
        """
        if record_id is None:
            # 使用文件名作为 ID
            record_id = Path(image_path).stem

        record = VectorRecord(
            id=record_id,
            image_path=image_path,
            aircraft_embedding=aircraft_emb,
            airline_embedding=airline_emb,
            aircraft_type=result["aircraft"]["class_name"],
            airline=result["airline"]["class_name"],
            aircraft_confidence=result["aircraft"]["confidence"],
            airline_confidence=result["airline"]["confidence"]
        )

        self.vector_db.add_record(record)

    def batch_detect_new_classes(
        self,
        image_paths: List[str]
    ) -> Dict[str, List[int]]:
        """
        批量检测新类别

        Args:
            image_paths: 图片路径列表

        Returns:
            {"new_class_indices": [...], "outlier_scores": [...]}
        """
        if self.new_class_discovery is None:
            logger.warning("New class discovery not enabled")
            return {"new_class_indices": [], "outlier_scores": []}

        logger.info(f"Batch detecting new classes from {len(image_paths)} images...")

        # 获取所有特征向量
        all_embeddings = []
        for image_path in image_paths:
            aircraft_emb = self.predictor.aircraft_model.embed(
                image_path,
                imgsz=self.predictor.image_size,
                device=self.predictor.device,
                verbose=False
            )[0]

            airline_emb = self.predictor.airline_model.embed(
                image_path,
                imgsz=self.predictor.image_size,
                device=self.predictor.device,
                verbose=False
            )[0]

            if hasattr(aircraft_emb, 'cpu'):
                aircraft_emb = aircraft_emb.cpu().numpy()
            if hasattr(airline_emb, 'cpu'):
                airline_emb = airline_emb.cpu().numpy()

            aircraft_emb = np.array(aircraft_emb).flatten()
            airline_emb = np.array(airline_emb).flatten()

            # 融合两个向量
            fused_emb = (aircraft_emb + airline_emb) / 2
            all_embeddings.append(fused_emb)

        embeddings_array = np.vstack(all_embeddings)

        # 使用 HDBSCAN 检测新类别
        new_class_indices = self.new_class_discovery.discover_new_classes(embeddings_array)

        return {
            "new_class_indices": new_class_indices,
            "stats": self.new_class_discovery.get_statistics()
        }

    def add_historical_records(
        self,
        records: List[VectorRecord]
    ) -> int:
        """
        添加历史记录到向量数据库

        Args:
            records: 记录列表

        Returns:
            成功添加的数量
        """
        if self.vector_db is None:
            logger.warning("Vector database not available")
            return 0

        return self.vector_db.add_records(records)

    def search_similar_by_id(
        self,
        record_id: str,
        top_k: int = None
    ) -> List[SimilarityResult]:
        """
        根据记录 ID 搜索相似记录

        Args:
            record_id: 记录 ID
            top_k: 返回的 Top-K 结果

        Returns:
            相似度结果列表
        """
        if self.vector_db is None:
            return []

        if top_k is None:
            top_k = self.top_k_similar

        # 从数据库获取记录
        if not hasattr(self.vector_db, '_records') or record_id not in self.vector_db._records:
            logger.warning(f"Record {record_id} not found in database")
            return []

        record = self.vector_db._records[record_id]

        return self.vector_db.search_similar(
            aircraft_embedding=record.aircraft_embedding,
            airline_embedding=record.airline_embedding,
            top_k=top_k
        )

    def get_db_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        if self.vector_db is None:
            return {"available": False}

        stats = self.vector_db.get_statistics()
        stats["vector_search_enabled"] = self.enable_vector_search
        stats["new_class_detection_enabled"] = self.enable_new_class_detection
        return stats

    def load_models(self):
        """加载所有模型"""
        self.predictor.load_models()

    def save_database(self):
        """保存向量数据库"""
        if self.vector_db is not None:
            self.vector_db.save()

    def load_database(self):
        """加载向量数据库"""
        if self.vector_db is not None:
            self.vector_db.load()
