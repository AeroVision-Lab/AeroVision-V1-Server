"""
Aerovision Inference 使用示例

演示如何使用重构后的inference包，所有配置通过接口参数传入
"""

from pathlib import Path
from PIL import Image

# 导入推理模块
from aerovision_inference import (
    AircraftClassifier,
    AirlineClassifier,
    RegistrationOCR,
    QualityAssessor
)


def example_aircraft_classification():
    """示例1：机型分类"""
    print("=" * 60)
    print("示例1：机型分类")
    print("=" * 60)

    # 初始化分类器（通过参数传入模型路径）
    classifier = AircraftClassifier(
        model_path="/path/to/aircraft_model.pt",
        device="cpu",  # 或 "cuda"
        image_size=640
    )

    # 加载图像
    image = Image.open("/path/to/aircraft_image.jpg")

    # 预测
    result = classifier.predict(image, top_k=5)

    # 输出结果
    print(f"Top-1 预测: {result['top1']['class']} (置信度: {result['top1']['confidence']:.4f})")
    print(f"\nTop-5 预测:")
    for i, pred in enumerate(result['predictions'], 1):
        print(f"  {i}. {pred['class']}: {pred['confidence']:.4f}")


def example_airline_classification():
    """示例2：航司分类"""
    print("\n" + "=" * 60)
    print("示例2：航司分类")
    print("=" * 60)

    # 初始化分类器
    classifier = AirlineClassifier(
        model_path="/path/to/airline_model.pt",
        device="cpu",
        image_size=640
    )

    # 加载图像
    image = Image.open("/path/to/aircraft_image.jpg")

    # 预测
    result = classifier.predict(image, top_k=5)

    # 输出结果
    print(f"Top-1 预测: {result['top1']['class']} (置信度: {result['top1']['confidence']:.4f})")
    print(f"\nTop-5 预测:")
    for i, pred in enumerate(result['predictions'], 1):
        print(f"  {i}. {pred['class']}: {pred['confidence']:.4f}")


def example_ocr_local():
    """示例3：OCR识别（本地模式）"""
    print("\n" + "=" * 60)
    print("示例3：OCR识别（本地模式）")
    print("=" * 60)

    # 初始化OCR（本地模式）
    ocr = RegistrationOCR(
        mode="local",           # 使用本地PaddleOCR
        lang="ch",              # 语言
        use_angle_cls=True,     # 使用角度分类
        enabled=True
    )

    # 加载图像
    image = Image.open("/path/to/aircraft_image.jpg")

    # 识别注册号
    result = ocr.recognize(image)

    # 输出结果
    print(f"注册号: {result['registration']}")
    print(f"置信度: {result['confidence']:.4f}")
    print(f"原始文本: {result['raw_text']}")

    # 显示YOLO格式目标框
    if result['yolo_boxes']:
        print(f"\n检测到 {len(result['yolo_boxes'])} 个文本框:")
        for i, box in enumerate(result['yolo_boxes'], 1):
            print(f"  框{i}: {box['text']} (置信度: {box['confidence']:.4f})")
            print(f"      位置: x={box['x_center']:.4f}, y={box['y_center']:.4f}, "
                  f"w={box['width']:.4f}, h={box['height']:.4f}")


def example_ocr_api():
    """示例4：OCR识别（API模式）"""
    print("\n" + "=" * 60)
    print("示例4：OCR识别（API模式）")
    print("=" * 60)

    # 初始化OCR（API模式）
    ocr = RegistrationOCR(
        mode="api",                    # 使用外部API
        api_url="http://localhost:8000/v2/models/ocr/infer",  # PaddleX后端地址
        timeout=30,
        enabled=True
    )

    # 加载图像（API模式需要文件路径）
    image_path = "/path/to/aircraft_image.jpg"

    # 识别注册号
    result = ocr.recognize(image_path)

    # 输出结果
    print(f"注册号: {result['registration']}")
    print(f"置信度: {result['confidence']:.4f}")
    print(f"原始文本: {result['raw_text']}")

    # 显示YOLO格式目标框
    if result['yolo_boxes']:
        print(f"\n检测到 {len(result['yolo_boxes'])} 个文本框:")
        for i, box in enumerate(result['yolo_boxes'], 1):
            print(f"  框{i}: {box['text']} (置信度: {box['confidence']:.4f})")


def example_quality_assessment():
    """示例5：质量评估（纯CV实现）"""
    print("\n" + "=" * 60)
    print("示例5：质量评估（纯CV实现）")
    print("=" * 60)

    # 初始化质量评估器（自定义配置）
    assessor = QualityAssessor(
        sharpness_weight=0.3,      # 清晰度权重
        exposure_weight=0.2,        # 曝光权重
        composition_weight=0.15,    # 构图权重
        noise_weight=0.2,           # 噪点权重
        color_weight=0.15,          # 色彩权重
        pass_threshold=0.6          # 通过阈值
    )

    # 加载图像
    image = Image.open("/path/to/aircraft_image.jpg")

    # 综合评估
    result = assessor.assess(image)

    # 输出结果
    if result['success']:
        print(f"质量评分: {result['score']:.4f}")
        print(f"是否通过: {'是' if result['pass'] else '否'}")
        print(f"\n详细评分:")
        for metric, score in result['details'].items():
            print(f"  {metric}: {score:.4f}")
    else:
        print(f"评估失败: {result.get('error', 'Unknown error')}")

    # 快速评估（仅清晰度）
    quick_result = assessor.quick_assess(image)
    print(f"\n快速评估（清晰度）: {quick_result['sharpness']:.4f}")
    print(f"是否清晰: {'是' if quick_result['pass'] else '否'}")


def example_complete_pipeline():
    """示例6：完整推理流程"""
    print("\n" + "=" * 60)
    print("示例6：完整推理流程")
    print("=" * 60)

    # 1. 初始化所有模型
    aircraft_classifier = AircraftClassifier(
        model_path="/path/to/aircraft_model.pt",
        device="cpu"
    )

    airline_classifier = AirlineClassifier(
        model_path="/path/to/airline_model.pt",
        device="cpu"
    )

    ocr = RegistrationOCR(
        mode="api",
        api_url="http://localhost:8000/v2/models/ocr/infer"
    )

    quality_assessor = QualityAssessor(
        pass_threshold=0.6
    )

    # 2. 加载图像
    image_path = "/path/to/aircraft_image.jpg"
    image = Image.open(image_path)

    # 3. 质量评估
    print("步骤1: 质量评估")
    quality_result = quality_assessor.assess(image)
    print(f"  质量评分: {quality_result['score']:.4f}")
    print(f"  是否通过: {'是' if quality_result['pass'] else '否'}")

    if not quality_result['pass']:
        print("  图片质量不合格，跳过后续推理")
        return

    # 4. 机型分类
    print("\n步骤2: 机型分类")
    aircraft_result = aircraft_classifier.predict(image, top_k=1)
    print(f"  机型: {aircraft_result['top1']['class']}")
    print(f"  置信度: {aircraft_result['top1']['confidence']:.4f}")

    # 5. 航司分类
    print("\n步骤3: 航司分类")
    airline_result = airline_classifier.predict(image, top_k=1)
    print(f"  航司: {airline_result['top1']['class']}")
    print(f"  置信度: {airline_result['top1']['confidence']:.4f}")

    # 6. OCR识别
    print("\n步骤4: 注册号识别")
    ocr_result = ocr.recognize(image_path)
    print(f"  注册号: {ocr_result['registration']}")
    print(f"  置信度: {ocr_result['confidence']:.4f}")

    # 7. 汇总结果
    print("\n" + "=" * 60)
    print("推理结果汇总")
    print("=" * 60)
    print(f"质量评分: {quality_result['score']:.4f}")
    print(f"机型: {aircraft_result['top1']['class']} ({aircraft_result['top1']['confidence']:.4f})")
    print(f"航司: {airline_result['top1']['class']} ({airline_result['top1']['confidence']:.4f})")
    print(f"注册号: {ocr_result['registration']} ({ocr_result['confidence']:.4f})")


def example_configuration_management():
    """示例7：配置管理"""
    print("\n" + "=" * 60)
    print("示例7：配置管理")
    print("=" * 60)

    # 推荐的配置管理方式：使用配置字典
    config = {
        # 模型路径配置
        "aircraft_model_path": "/path/to/aircraft_model.pt",
        "airline_model_path": "/path/to/airline_model.pt",

        # 设备配置
        "device": "cuda",  # 或 "cpu"

        # OCR配置
        "ocr": {
            "mode": "api",
            "api_url": "http://localhost:8000/v2/models/ocr/infer",
            "timeout": 30
        },

        # 质量评估配置
        "quality": {
            "sharpness_weight": 0.3,
            "exposure_weight": 0.2,
            "composition_weight": 0.15,
            "noise_weight": 0.2,
            "color_weight": 0.15,
            "pass_threshold": 0.6
        }
    }

    # 使用配置初始化
    aircraft_cls = AircraftClassifier(
        model_path=config["aircraft_model_path"],
        device=config["device"]
    )

    airline_cls = AirlineClassifier(
        model_path=config["airline_model_path"],
        device=config["device"]
    )

    ocr = RegistrationOCR(**config["ocr"])

    quality_assessor = QualityAssessor(**config["quality"])

    # 获取模型信息
    print("机型分类器信息:", aircraft_cls.get_model_info())
    print("OCR配置信息:", ocr.get_info())
    print("质量评估配置:", quality_assessor.get_info())


if __name__ == "__main__":
    # 取消注释以运行相应示例

    # example_aircraft_classification()
    # example_airline_classification()
    # example_ocr_local()
    # example_ocr_api()
    # example_quality_assessment()
    # example_complete_pipeline()
    # example_configuration_management()

    print("\n提示: 取消注释相应的示例函数以运行")
