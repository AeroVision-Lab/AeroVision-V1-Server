"""
模型模块
"""

from .yolov8_cls_wrapper import YOLOv8Classifier

__all__ = ["YOLOv8Classifier"]
