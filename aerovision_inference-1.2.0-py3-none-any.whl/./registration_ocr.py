"""
注册号OCR识别
支持本地PaddleOCR、外部API和Qwen三种模式
"""

import os
import logging
import re
import base64
import json
import requests
from typing import Dict, Any, Union, List, Optional
from pathlib import Path
from PIL import Image
import numpy as np

from utils.image_processing import load_image

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 注册号正则表达式：匹配国际民航组织（ICAO）格式的注册号
# 格式：[国家代码]-[注册号]，如 B-1234（中国）、N1234（美国）、G-XXXX（英国）
REGISTRATION_PATTERN = re.compile(
    r"\b([A-Z]{1,2})[- ]?([A-HJ-NP-Z0-9][A-HJ-NP-Z0-9]{0,4})\b"
)

# 延迟导入PaddleOCR以避免numpy 2.x兼容性问题
_PaddleOCR = None

def get_paddleocr():
    """延迟导入PaddleOCR"""
    global _PaddleOCR
    if _PaddleOCR is None:
        from paddleocr import PaddleOCR
        _PaddleOCR = PaddleOCR
    return _PaddleOCR


class RegistrationOCR:
    """注册号OCR识别器 - 支持本地和API两种模式"""

    def __init__(
        self,
        mode: str = "hybrid",
        # 本地模式参数
        lang: str = "ch",
        use_angle_cls: bool = True,
        # API模式参数
        api_url: str = "http://localhost:8000/v2/models/ocr/infer",
        timeout: int = 30,
        # Qwen模式参数
        qwen_model: str = "qwen3-vl-plus",
        confidence_threshold: float = 0.8,
        enabled: bool = True
    ):
        """
        初始化注册号OCR识别器

        Args:
            mode: OCR模式，'hybrid'（混合模式，Qwen+PaddleOCR）、'qwen'（Qwen API）、'local'（本地PaddleOCR）或 'api'（外部API）
                lang: OCR语言（仅本地模式），默认ch（中文）
                use_angle_cls: 是否使用角度分类（仅本地模式），默认True
                api_url: OCR API地址（仅API模式），默认localhost:8000
                timeout: API超时时间（仅API和Qwen模式），默认30秒
                qwen_model: Qwen模型名称（仅Qwen和混合模式），可选 qwen3-vl-flash, qwen3-vl-plus, qwen3.5-plus，默认 qwen3-vl-plus
                confidence_threshold: 混合模式下的置信度阈值，默认0.8。当Qwen置信度低于此值时使用PaddleOCR
                enabled: 是否启用OCR，默认True
        """
        self.enabled = enabled
        self.lang = lang
        self.use_angle_cls = use_angle_cls
        self.api_url = api_url
        self.timeout = timeout
        self.qwen_model = qwen_model
        self.confidence_threshold = confidence_threshold

        if not self.enabled:
            logger.info("OCR is disabled")
            return

        # Hybrid 模式：使用 Qwen + PaddleOCR
        # Auto 模式：优先使用 Hybrid，如果 API key 不存在则只用 PaddleOCR
        if mode == "auto":
            if os.getenv("DASHSCOPE_API_KEY"):
                self.mode = "hybrid"
                logger.info("Auto mode: Using hybrid OCR (Qwen + PaddleOCR)")
            else:
                self.mode = "local"
                logger.info("Auto mode: Using local PaddleOCR (DASHSCOPE_API_KEY not found)")
        else:
            self.mode = mode

        # 初始化需要的 OCR 客户端
        if self.mode == "hybrid":
            self._init_qwen_ocr()
            self._init_local_ocr()
            logger.info(f"Hybrid OCR mode initialized (qwen={qwen_model}, threshold={confidence_threshold})")
        elif self.mode == "local":
            self._init_local_ocr()
        elif self.mode == "qwen":
            self._init_qwen_ocr()
        elif self.mode == "api":
            logger.info(f"OCR API mode initialized (url={api_url})")
        else:
            raise ValueError(f"不支持的OCR模式: {mode}，必须是 'hybrid', 'auto', 'qwen'、'local' 或 'api'")

    def _init_local_ocr(self):
        """初始化本地PaddleOCR"""
        try:
            PaddleOCR = get_paddleocr()
            # 尝试不使用 show_log 参数
            try:
                self.ocr = PaddleOCR(
                    use_angle_cls=self.use_angle_cls,
                    lang=self.lang
                )
            except TypeError:
                # 如果还是失败，尝试不传 lang 参数
                self.ocr = PaddleOCR(
                    use_angle_cls=self.use_angle_cls
                )
            logger.info(
                f"PaddleOCR initialized (lang={self.lang}, use_angle_cls={self.use_angle_cls})"
            )
        except Exception as e:
            logger.error(f"Failed to initialize PaddleOCR: {e}")
            raise

    def _init_qwen_ocr(self):
        """初始化 Qwen OCR 客户端"""
        try:
            from dashscope_client import DashScopeOCRClient
            self.qwen_client = DashScopeOCRClient(
                model=self.qwen_model,
                timeout=self.timeout
            )
            logger.info(f"Qwen OCR client initialized (model={self.qwen_model})")
        except ImportError as e:
            logger.error(f"Failed to import DashScopeOCRClient: {e}")
            raise ImportError(
                "DashScope OCR client is required for qwen mode. "
                "Please ensure dashscope_client.py is available."
            )
        except Exception as e:
            logger.error(f"Failed to initialize Qwen OCR: {e}")
            raise

    def _call_ocr_api(self, image_path: str) -> Optional[Dict]:
        """
        调用 OCR API（API模式）

        Args:
            image_path: 图片文件路径

        Returns:
            API 响应数据
        """
        try:
            # 读取图片并转换为 base64 编码
            with open(image_path, 'rb') as f:
                image_bytes = f.read()
                image_base64 = base64.b64encode(image_bytes).decode('utf-8')

            # 构建请求数据，使用 base64 编码的图片
            payload = {
                "inputs": [
                    {
                        "name": "input",
                        "shape": [1, 1],
                        "datatype": "BYTES",
                        "data": [
                            json.dumps({
                                "file": f"data:image/jpeg;base64,{image_base64}",
                                "visualize": False
                            })
                        ]
                    }
                ],
                "outputs": [
                    {
                        "name": "output"
                    }
                ]
            }

            # 发送请求
            response = requests.post(
                self.api_url,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=self.timeout
            )
            response.raise_for_status()

            # 解析响应（兼容 BYTES 嵌套 JSON 与多重转义）
            result = response.json()
            if not result.get('outputs'):
                logger.error("No outputs in API response")
                return None

            outputs = result.get('outputs', [])
            # 优先按名称找到名为 output 的输出
            output_obj = None
            for out in outputs:
                if out.get('name') == 'output':
                    output_obj = out
                    break
            if output_obj is None and outputs:
                output_obj = outputs[0]

            data_list = output_obj.get('data') or []
            if not data_list:
                logger.error("Empty 'data' in OCR API response output")
                return None

            raw_val = data_list[0]

            def _to_text(val: Any) -> Optional[str]:
                if val is None:
                    return None
                if isinstance(val, bytes):
                    try:
                        return val.decode('utf-8', errors='replace')
                    except Exception:
                        return None
                if isinstance(val, str):
                    return val
                # Triton 有时会返回 {"b64": "..."}
                if isinstance(val, dict):
                    b64 = val.get('b64') or val.get('base64')
                    if b64:
                        try:
                            decoded = base64.b64decode(b64)
                            return decoded.decode('utf-8', errors='replace')
                        except Exception as e:
                            logger.error(f"Failed to base64-decode OCR output: {e}")
                            return None
                return None

            text = _to_text(raw_val)
            if text is None:
                logger.error("Unsupported OCR output value type; cannot convert to text")
                return None

            # 有些后端会把 JSON 再次转义，需要尝试多次反序列化
            parsed: Any = text
            for _ in range(2):
                try:
                    parsed = json.loads(parsed)
                except Exception:
                    break
                # 如果仍是字符串且看起来像 JSON，则再解一层
                if isinstance(parsed, str) and (parsed.strip().startswith('{') or parsed.strip().startswith('[')):
                    continue
                else:
                    break

            if isinstance(parsed, str):
                # 最终还是字符串且不是 JSON，无法解析
                logger.error("OCR output is not valid JSON after unescaping")
                return None

            if not isinstance(parsed, dict):
                logger.error("OCR output JSON is not an object")
                return None

            return parsed

        except FileNotFoundError as e:
            logger.error(f"Image file not found: {image_path}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"OCR API request failed: {e}")
            return None
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            logger.error(f"Failed to parse OCR API response: {e}")
            return None

    def recognize_local(
        self,
        image: Union[str, Path, bytes, "Image.Image"]
    ) -> Dict[str, Any]:
        """
        使用本地PaddleOCR识别注册号

        Args:
            image: 图像输入

        Returns:
            识别结果
        """
        # 加载图像
        pil_image = load_image(image)
        img_width, img_height = pil_image.size

        # 转换为numpy数组（PaddleOCR需要）
        image_array = np.array(pil_image)

        # OCR识别
        ocr_results = self.ocr.ocr(image_array)

        logger.debug(f"OCR raw results: {ocr_results}")

        # 如果没有识别结果，返回空结果
        if not ocr_results or not ocr_results[0]:
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

        # PaddleOCR返回格式：[[[x1,y1], [x2,y2], [x3,y3], [x4,y4]], (text, confidence), ...]
        all_texts = []
        yolo_boxes = []

        for result in ocr_results[0]:
            if not result or len(result) < 2:
                continue

            box_points = result[0]  # [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
            text_info = result[1]   # (text, confidence)

            if not box_points or not text_info:
                continue

            text = text_info[0]
            confidence = text_info[1]

            # 提取边界框（四角坐标转xmin, ymin, xmax, ymax）
            xmin = min(point[0] for point in box_points)
            ymin = min(point[1] for point in box_points)
            xmax = max(point[0] for point in box_points)
            ymax = max(point[1] for point in box_points)

            # 转换为YOLO格式（归一化）
            x_center = (xmin + xmax) / 2.0 / img_width
            y_center = (ymin + ymax) / 2.0 / img_height
            box_width = (xmax - xmin) / img_width
            box_height = (ymax - ymin) / img_height

            all_texts.append({
                "text": text,
                "confidence": confidence,
                "box": [x_center, y_center, box_width, box_height]
            })

            # YOLO格式目标框
            yolo_boxes.append({
                "class_id": 0,
                "x_center": round(x_center, 6),
                "y_center": round(y_center, 6),
                "width": round(box_width, 6),
                "height": round(box_height, 6),
                "text": text,
                "confidence": float(confidence)
            })

        logger.debug(f"Extracted texts: {all_texts}")

        # 合并所有文本用于原始输出
        raw_text = " ".join([t["text"] for t in all_texts])

        # 使用正则表达式过滤出注册号
        matches = self._filter_registrations(all_texts)

        # 如果没有匹配的注册号，返回空结果
        if not matches:
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": raw_text,
                "all_matches": [],
                "yolo_boxes": yolo_boxes
            }

        # 返回置信度最高的匹配
        best_match = max(matches, key=lambda x: x["confidence"])
        return {
            "registration": best_match["text"],
            "confidence": float(best_match["confidence"]),
            "raw_text": raw_text,
            "all_matches": matches,
            "yolo_boxes": yolo_boxes
        }

    def recognize_qwen(
        self,
        image: Union[str, Path, bytes, "Image.Image"]
    ) -> Dict[str, Any]:
        """
        使用 Qwen API 识别注册号

        Args:
            image: 图像输入

        Returns:
            识别结果
        """
        try:
            result = self.qwen_client.recognize(image)
            return result
        except Exception as e:
            logger.error(f"Qwen OCR recognition failed: {e}")
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

    def recognize_hybrid(
        self,
        image: Union[str, Path, bytes, "Image.Image"]
    ) -> Dict[str, Any]:
        """
        使用混合 OCR 策略识别注册号（Qwen + PaddleOCR）

        策略：
        1. 首先使用 Qwen3-VL-Plus 识别
        2. 如果 Qwen 成功且置信度 >= 阈值，直接返回
        3. 如果 Qwen 失败或置信度 < 阈值，使用 PaddleOCR 备份

        Args:
            image: 图像输入

        Returns:
            识别结果
        """
        # 步骤1：尝试 Qwen3-VL-Plus
        try:
            logger.debug("Attempting Qwen3-VL-Plus recognition...")
            qwen_result = self.qwen_client.recognize(image)

            # 检查 Qwen 结果
            qwen_registration = qwen_result.get("registration", "")
            qwen_confidence = qwen_result.get("confidence", 0.0)

            # 如果 Qwen 识别成功且置信度足够高，直接返回
            if qwen_registration and qwen_confidence >= self.confidence_threshold:
                logger.info(
                    f"Qwen3-VL-Plus succeeded: {qwen_registration} "
                    f"(confidence={qwen_confidence:.2f})"
                )
                return qwen_result
            elif qwen_registration and qwen_confidence < self.confidence_threshold:
                logger.info(
                    f"Qwen3-VL-Plus confidence too low: {qwen_registration} "
                    f"(confidence={qwen_confidence:.2f} < threshold={self.confidence_threshold}), "
                    f"falling back to PaddleOCR"
                )
            else:
                logger.info(
                    f"Qwen3-VL-Plus returned empty result, "
                    f"falling back to PaddleOCR"
                )
        except Exception as e:
            logger.warning(f"Qwen3-VL-Plus recognition failed: {e}, falling back to PaddleOCR")

        # 步骤2：降级到 PaddleOCR
        try:
            logger.debug("Attempting PaddleOCR recognition...")
            paddle_result = self.recognize_local(image)

            paddle_registration = paddle_result.get("registration", "")
            paddle_confidence = paddle_result.get("confidence", 0.0)

            if paddle_registration:
                logger.info(
                    f"PaddleOCR succeeded: {paddle_registration} "
                    f"(confidence={paddle_confidence:.2f})"
                )
                return paddle_result
            else:
                logger.warning("PaddleOCR returned empty result")
                return paddle_result

        except Exception as e:
            logger.error(f"PaddleOCR recognition failed: {e}")
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

    def recognize_api(
        self,
        image: Union[str, Path]
    ) -> Dict[str, Any]:
        """
        使用外部API识别注册号

        Args:
            image: 图像文件路径

        Returns:
            识别结果
        """
        # 确保是文件路径
        image_path = str(image)

        # 获取图片尺寸
        pil_image = Image.open(image_path)
        img_width, img_height = pil_image.size

        # 调用 OCR API
        ocr_data = self._call_ocr_api(image_path)
        if not ocr_data:
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

        # 解析 OCR 结果
        try:
            pruned_result = ocr_data['result']['ocrResults'][0]['prunedResult']
            rec_texts = pruned_result.get('rec_texts', [])
            rec_scores = pruned_result.get('rec_scores', [])
            rec_boxes = pruned_result.get('rec_boxes', [])
            # 如果没有提供矩形框，尝试从多边形转换
            if (not rec_boxes) and pruned_result.get('rec_polys'):
                rec_boxes = []
                for poly in pruned_result['rec_polys']:
                    # poly: [[x1,y1],[x2,y2],[x3,y3],[x4,y4]]
                    xs = [p[0] for p in poly]
                    ys = [p[1] for p in poly]
                    xmin, xmax = min(xs), max(xs)
                    ymin, ymax = min(ys), max(ys)
                    rec_boxes.append([xmin, ymin, xmax, ymax])

            if not rec_texts:
                return {
                    "registration": "",
                    "confidence": 0.0,
                    "raw_text": "",
                    "all_matches": [],
                    "yolo_boxes": []
                }

        except (KeyError, IndexError) as e:
            logger.error(f"Failed to parse OCR results: {e}")
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

        all_texts = []
        yolo_boxes = []

        # 处理每个识别结果
        for i, (text, score, box) in enumerate(zip(rec_texts, rec_scores, rec_boxes)):
            # box 格式: [xmin, ymin, xmax, ymax]
            xmin, ymin, xmax, ymax = box

            # 转换为YOLO格式
            x_center = (xmin + xmax) / 2.0 / img_width
            y_center = (ymin + ymax) / 2.0 / img_height
            box_width = (xmax - xmin) / img_width
            box_height = (ymax - ymin) / img_height

            all_texts.append({
                "text": text,
                "confidence": score,
                "box": [x_center, y_center, box_width, box_height]
            })

            yolo_boxes.append({
                "class_id": 0,
                "x_center": round(x_center, 6),
                "y_center": round(y_center, 6),
                "width": round(box_width, 6),
                "height": round(box_height, 6),
                "text": text,
                "confidence": float(score)
            })

        raw_text = " ".join(rec_texts)
        matches = self._filter_registrations(all_texts)

        if not matches:
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": raw_text,
                "all_matches": [],
                "yolo_boxes": yolo_boxes
            }

        best_match = max(matches, key=lambda x: x["confidence"])

        return {
            "registration": best_match["text"],
            "confidence": float(best_match["confidence"]),
            "raw_text": raw_text,
            "all_matches": matches,
            "yolo_boxes": yolo_boxes
        }

    def recognize(
        self,
        image: Union[str, Path, bytes, "Image.Image"],
        output_yolo_txt: Optional[Union[str, Path]] = None
    ) -> Dict[str, Any]:
        """
        识别注册号（统一接口）

        Args:
            image: 图像输入，支持：
                - 文件路径（str或Path）
                - 字节流（bytes）
                - PIL Image对象
                - base64编码字符串
            output_yolo_txt: YOLO格式输出文件路径（可选），如果提供则保存到文件

        Returns:
            Dict: 识别结果
                {
                    "registration": "B-1234",  # 识别的注册号
                    "confidence": 0.95,       # 置信度
                    "raw_text": "B-1234",     # 原始识别文本
                    "all_matches": [           # 所有匹配的注册号
                        {"text": "B-1234", "confidence": 0.95}
                    ],
                    "yolo_boxes": [            # YOLO格式的目标框
                        {
                            "class_id": 0,
                            "x_center": 0.5,
                            "y_center": 0.3,
                            "width": 0.2,
                            "height": 0.1,
                            "text": "B-1234",
                            "confidence": 0.95
                        }
                    ]
                }
        """
        if not self.enabled:
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

        try:
            # 根据模式选择识别方法
            if self.mode == "local":
                result = self.recognize_local(image)
            elif self.mode == "hybrid":
                result = self.recognize_hybrid(image)
            elif self.mode == "qwen":
                result = self.recognize_qwen(image)
            elif self.mode == "api":
                result = self.recognize_api(image)
            else:
                raise ValueError(f"不支持的OCR模式: {self.mode}")

            # 如果指定了输出文件，保存YOLO格式
            if output_yolo_txt and result["yolo_boxes"]:
                self._save_yolo_format(result["yolo_boxes"], output_yolo_txt)

            return result

        except Exception as e:
            logger.error(f"OCR recognition error: {e}")
            return {
                "registration": "",
                "confidence": 0.0,
                "raw_text": "",
                "all_matches": [],
                "yolo_boxes": []
            }

    def _filter_registrations(
        self,
        ocr_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        使用正则表达式过滤出注册号

        Args:
            ocr_results: OCR识别结果列表

        Returns:
            List[Dict]: 匹配的注册号列表
        """
        matches = []

        for result in ocr_results:
            text = result["text"]
            confidence = result["confidence"]

            # 使用正则表达式匹配
            match = REGISTRATION_PATTERN.search(text)
            if match:
                # 提取完整的注册号
                registration = match.group(0)
                matches.append({
                    "text": registration,
                    "confidence": confidence,
                    "box": result.get("box")
                })

        return matches

    def _save_yolo_format(
        self,
        yolo_boxes: List[Dict[str, Any]],
        output_path: Union[str, Path]
    ) -> None:
        """
        将YOLO格式的目标框保存到.txt文件

        Args:
            yolo_boxes: YOLO格式的目标框列表
            output_path: 输出文件路径
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            for box in yolo_boxes:
                # YOLO格式: class_id x_center y_center width height
                line = f"{box['class_id']} {box['x_center']} {box['y_center']} {box['width']} {box['height']}\n"
                f.write(line)

        logger.info(f"YOLO format boxes saved to {output_path}")

    def get_info(self) -> Dict[str, Any]:
        """
        获取OCR信息

        Returns:
            Dict: OCR信息
        """
        info = {
            "type": self.mode,
            "enabled": self.enabled,
            "pattern": REGISTRATION_PATTERN.pattern
        }

        if self.mode == "local":
            info.update({
                "lang": self.lang,
                "use_angle_cls": self.use_angle_cls
            })
        elif self.mode == "hybrid":
            info.update({
                "qwen_model": self.qwen_model,
                "paddle_lang": self.lang,
                "paddle_angle_cls": self.use_angle_cls,
                "confidence_threshold": self.confidence_threshold,
                "timeout": self.timeout
            })
        elif self.mode == "qwen":
            info.update({
                "model": self.qwen_model,
                "timeout": self.timeout
            })
        elif self.mode == "api":
            info.update({
                "api_url": self.api_url,
                "timeout": self.timeout
            })

        return info

    def cleanup(self):
        """清理OCR资源，释放内存"""
        if self.mode == "local" and hasattr(self, 'ocr'):
            del self.ocr
            logger.info("Local OCR resources cleaned up")
        elif self.mode == "qwen" and hasattr(self, 'qwen_client'):
            del self.qwen_client
            logger.info("Qwen OCR client cleaned up")
        elif self.mode == "api":
            logger.info("OCR API client cleanup (no resources to release)")

    def __del__(self):
        """析构时自动清理"""
        self.cleanup()
