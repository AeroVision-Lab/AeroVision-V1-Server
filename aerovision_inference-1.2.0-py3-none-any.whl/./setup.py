"""
Aerovision-V1-inference Setup
"""

from setuptools import setup, find_packages

setup(
    name="aerovision-v1-inference",
    version="1.2.0",
    description="Aerovision-V1 Inference Library",
    long_description="飞机识别和注册号OCR推理库（支持混合OCR策略：Qwen3-VL-Plus + PaddleOCR）",
    long_description_content_type="text/markdown",
    author="wlx",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[
        "numpy<2.0",  # 兼容 PaddleOCR
        "opencv-python>=4.5.0",
        "paddleocr>=2.6.0",
        "paddlepaddle>=2.5.0",
        "requests>=2.25.0",
        "Pillow>=8.0.0",
        "dashscope>=1.14.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
