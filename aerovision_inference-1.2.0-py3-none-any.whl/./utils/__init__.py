"""
工具模块
"""

from .image_processing import load_image

__all__ = ["load_image"]
