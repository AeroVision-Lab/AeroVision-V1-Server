"""
图像处理工具
"""

from pathlib import Path
from typing import Union
import io
from PIL import Image
import base64


def load_image(image_input: Union[str, Path, bytes, io.BytesIO, Image.Image]) -> Image.Image:
    """
    加载图像，支持多种输入格式

    Args:
        image_input: 图像输入，支持：
            - 文件路径（str或Path）
            - 字节流（bytes或io.BytesIO）
            - base64编码字符串
            - PIL Image对象

    Returns:
        PIL.Image.Image: RGB格式的PIL Image对象

    Raises:
        ValueError: 不支持的输入类型或加载失败
    """
    if isinstance(image_input, Image.Image):
        # 已经是PIL Image
        return image_input.convert("RGB")

    if isinstance(image_input, (str, Path)):
        path_str = str(image_input)
        if isinstance(image_input, str) and is_base64_image(path_str):
            # Base64编码字符串
            image_data = base64.b64decode(path_str)
            image = Image.open(io.BytesIO(image_data))
        else:
            # 文件路径
            image = Image.open(path_str)
        return image.convert("RGB")

    if isinstance(image_input, bytes):
        # 字节数据
        image = Image.open(io.BytesIO(image_input))
        return image.convert("RGB")

    if isinstance(image_input, io.BytesIO):
        # BytesIO对象
        image = Image.open(image_input)
        return image.convert("RGB")

    raise ValueError(
        f"不支持的图像输入类型: {type(image_input)}。"
        "支持的类型: str, Path, bytes, io.BytesIO, PIL.Image"
    )


def is_base64_image(s: str) -> bool:
    """
    判断字符串是否是base64编码的图像

    Args:
        s: 待检测的字符串

    Returns:
        bool: 是否是base64图像
    """
    if len(s) < 10:
        return False
    # 检查是否只包含base64字符
    base64_chars = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=")
    return all(c in base64_chars for c in s)


def resize_image(image: Image.Image, size: int) -> Image.Image:
    """
    调整图像尺寸（保持宽高比）

    Args:
        image: PIL Image对象
        size: 目标尺寸（正方形边长）

    Returns:
        PIL.Image.Image: 调整尺寸后的图像
    """
    # 保持宽高比调整尺寸
    image.thumbnail((size, size), Image.LANCZOS)

    # 创建新的正方形图像
    new_image = Image.new("RGB", (size, size), (0, 0, 0))

    # 居中粘贴
    width, height = image.size
    x = (size - width) // 2
    y = (size - height) // 2
    new_image.paste(image, (x, y))

    return new_image
