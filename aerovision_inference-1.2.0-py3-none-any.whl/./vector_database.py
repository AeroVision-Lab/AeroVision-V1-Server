"""
向量数据库模块
使用 FAISS 实现向量检索，支持双模型倒数排名融合和 HDBSCAN 新类别发现
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
import json
from datetime import datetime

import numpy as np

# FAISS 导入（支持 graceful degradation）
FAISS_AVAILABLE = False
try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    logging.warning("faiss not installed. Install with: pip install faiss-cpu")

# HDBSCAN 导入
HDBSCAN_AVAILABLE = False
try:
    import hdbscan
    HDBSCAN_AVAILABLE = True
except ImportError:
    logging.warning("hdbscan not installed. Install with: pip install hdbscan")

logger = logging.getLogger(__name__)


@dataclass
class VectorRecord:
    """向量记录"""
    id: str  # 记录唯一ID（可以是文件名或数据库主键）
    image_path: str  # 图片路径
    aircraft_embedding: np.ndarray  # 机型特征向量
    airline_embedding: np.ndarray  # 航司特征向量
    aircraft_type: Optional[str] = None  # 机型
    airline: Optional[str] = None  # 航司
    aircraft_confidence: Optional[float] = None  # 机型置信度
    airline_confidence: Optional[float] = None  # 航司置信度
    timestamp: Optional[str] = None  # 时间戳
    metadata: Optional[Dict[str, Any]] = None  # 额外元数据

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于存储）"""
        return {
            "id": self.id,
            "image_path": self.image_path,
            "aircraft_embedding": self.aircraft_embedding.tolist(),
            "airline_embedding": self.airline_embedding.tolist(),
            "aircraft_type": self.aircraft_type,
            "airline": self.airline,
            "aircraft_confidence": self.aircraft_confidence,
            "airline_confidence": self.airline_confidence,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VectorRecord":
        """从字典创建"""
        return cls(
            id=data["id"],
            image_path=data["image_path"],
            aircraft_embedding=np.array(data["aircraft_embedding"]),
            airline_embedding=np.array(data["airline_embedding"]),
            aircraft_type=data.get("aircraft_type"),
            airline=data.get("airline"),
            aircraft_confidence=data.get("aircraft_confidence"),
            airline_confidence=data.get("airline_confidence"),
            timestamp=data.get("timestamp"),
            metadata=data.get("metadata")
        )


@dataclass
class SimilarityResult:
    """相似度检索结果"""
    id: str
    image_path: str
    similarity: float
    aircraft_type: Optional[str] = None
    airline: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class VectorDatabase:
    """
    向量数据库
    使用 FAISS 实现向量检索，支持双模型倒数排名融合
    """

    def __init__(
        self,
        index_path: Optional[str] = None,
        metadata_path: Optional[str] = None,
        embedding_dim: int = 128,
        metric_type: str = "L2"
    ):
        """
        初始化向量数据库

        Args:
            index_path: FAISS 索引文件路径
            metadata_path: 元数据文件路径
            embedding_dim: 特征向量维度
            metric_type: 距离度量类型 (L2, IP)
        """
        self.index_path = Path(index_path) if index_path else None
        self.metadata_path = Path(metadata_path) if metadata_path else None
        self.embedding_dim = embedding_dim
        self.metric_type = metric_type

        self._aircraft_index = None
        self._airline_index = None
        self._records: Dict[str, VectorRecord] = {}
        self._id_to_index: Dict[str, int] = {}
        self._next_index = 0

        if not FAISS_AVAILABLE:
            logger.warning("FAISS not available, VectorDatabase will be inoperable")
        else:
            self._initialize_indexes()

        logger.info(f"VectorDatabase initialized (embedding_dim={embedding_dim}, metric={metric_type})")

    def _initialize_indexes(self):
        """初始化 FAISS 索引"""
        if self.metric_type == "L2":
            self._aircraft_index = faiss.IndexFlatL2(self.embedding_dim)
            self._airline_index = faiss.IndexFlatL2(self.embedding_dim)
        elif self.metric_type == "IP":
            self._aircraft_index = faiss.IndexFlatIP(self.embedding_dim)
            self._airline_index = faiss.IndexFlatIP(self.embedding_dim)
        else:
            raise ValueError(f"Unsupported metric type: {self.metric_type}")

    def add_record(self, record: VectorRecord) -> bool:
        """
        添加向量记录

        Args:
            record: 向量记录

        Returns:
            是否添加成功
        """
        if not FAISS_AVAILABLE:
            logger.error("FAISS not available")
            return False

        if record.id in self._records:
            logger.warning(f"Record {record.id} already exists, skipping")
            return False

        # 检查向量维度
        if record.aircraft_embedding.shape[0] != self.embedding_dim:
            logger.error(f"Aircraft embedding dimension mismatch: {record.aircraft_embedding.shape[0]} != {self.embedding_dim}")
            return False
        if record.airline_embedding.shape[0] != self.embedding_dim:
            logger.error(f"Airline embedding dimension mismatch: {record.airline_embedding.shape[0]} != {self.embedding_dim}")
            return False

        # 分配索引
        idx = self._next_index
        self._id_to_index[record.id] = idx
        self._records[record.id] = record
        self._next_index += 1

        # 添加到索引（需要 reshape 为 (1, dim)）
        aircraft_vec = record.aircraft_embedding.reshape(1, -1).astype('float32')
        airline_vec = record.airline_embedding.reshape(1, -1).astype('float32')

        self._aircraft_index.add(aircraft_vec)
        self._airline_index.add(airline_vec)

        logger.debug(f"Added record {record.id} at index {idx}")
        return True

    def add_records(self, records: List[VectorRecord]) -> int:
        """
        批量添加向量记录

        Args:
            records: 向量记录列表

        Returns:
            成功添加的数量
        """
        success_count = 0
        for record in records:
            if self.add_record(record):
                success_count += 1
        return success_count

    def _reciprocal_rank_fusion(
        self,
        aircraft_results: Tuple[List[int], List[float]],
        airline_results: Tuple[List[int], List[float]],
        k: int = 60
    ) -> List[Tuple[int, float]]:
        """
        倒数排名融合 (Reciprocal Rank Fusion)

        Args:
            aircraft_results: (索引列表, 距离列表)
            airline_results: (索引列表, 距离列表)
            k: RRF 常数

        Returns:
            融合后的 (索引列表, 融合分数列表)
        """
        aircraft_indices, aircraft_distances = aircraft_results
        airline_indices, airline_distances = airline_results

        # 构建排名映射
        aircraft_rank = {idx: rank + 1 for rank, idx in enumerate(aircraft_indices)}
        airline_rank = {idx: rank + 1 for rank, idx in enumerate(airline_indices)}

        # 收集所有出现的索引
        all_indices = set(aircraft_indices) | set(airline_indices)

        # 计算融合分数
        scores = []
        for idx in all_indices:
            rrf_score = 0.0
            if idx in aircraft_rank:
                rrf_score += 1.0 / (k + aircraft_rank[idx])
            if idx in airline_rank:
                rrf_score += 1.0 / (k + airline_rank[idx])
            scores.append((idx, rrf_score))

        # 按融合分数降序排序
        scores.sort(key=lambda x: x[1], reverse=True)

        return scores

    def search_similar(
        self,
        aircraft_embedding: np.ndarray,
        airline_embedding: np.ndarray,
        top_k: int = 10,
        use_rrf: bool = True
    ) -> List[SimilarityResult]:
        """
        搜索相似向量

        Args:
            aircraft_embedding: 机型特征向量
            airline_embedding: 航司特征向量
            top_k: 返回的 Top-K 结果
            use_rrf: 是否使用倒数排名融合

        Returns:
            相似度结果列表
        """
        if not FAISS_AVAILABLE:
            logger.error("FAISS not available")
            return []

        if len(self._records) == 0:
            logger.warning("Database is empty")
            return []

        # Reshape 查询向量
        aircraft_query = aircraft_embedding.reshape(1, -1).astype('float32')
        airline_query = airline_embedding.reshape(1, -1).astype('float32')

        # 调整 top_k
        search_k = min(top_k, len(self._records))

        # 分别检索
        aircraft_distances, aircraft_indices = self._aircraft_index.search(
            aircraft_query,
            search_k
        )
        airline_distances, airline_indices = self._airline_index.search(
            airline_query,
            search_k
        )

        # 提取结果
        aircraft_indices = aircraft_indices[0].tolist()
        aircraft_distances = aircraft_distances[0].tolist()
        airline_indices = airline_indices[0].tolist()
        airline_distances = airline_distances[0].tolist()

        # 使用倒数排名融合
        if use_rrf:
            fused_scores = self._reciprocal_rank_fusion(
                (aircraft_indices, aircraft_distances),
                (airline_indices, airline_distances)
            )

            # 构建结果
            results = []
            for idx, score in fused_scores[:top_k]:
                # 找到对应的记录 ID
                record_id = None
                for rid, ridx in self._id_to_index.items():
                    if ridx == idx:
                        record_id = rid
                        break

                if record_id is None:
                    continue

                record = self._records[record_id]
                results.append(SimilarityResult(
                    id=record.id,
                    image_path=record.image_path,
                    similarity=score,
                    aircraft_type=record.aircraft_type,
                    airline=record.airline,
                    metadata=record.metadata
                ))
        else:
            # 简单平均
            combined_scores = {}
            for idx, dist in zip(aircraft_indices, aircraft_distances):
                combined_scores[idx] = combined_scores.get(idx, 0) + dist
            for idx, dist in zip(airline_indices, airline_distances):
                combined_scores[idx] = combined_scores.get(idx, 0) + dist

            # 排序（距离越小越好）
            sorted_scores = sorted(combined_scores.items(), key=lambda x: x[1])

            # 构建结果
            results = []
            for idx, score in sorted_scores[:top_k]:
                record_id = None
                for rid, ridx in self._id_to_index.items():
                    if ridx == idx:
                        record_id = rid
                        break

                if record_id is None:
                    continue

                record = self._records[record_id]
                results.append(SimilarityResult(
                    id=record.id,
                    image_path=record.image_path,
                    similarity=1.0 / (score + 1e-6),  # 转换为相似度
                    aircraft_type=record.aircraft_type,
                    airline=record.airline,
                    metadata=record.metadata
                ))

        return results

    def save(self, index_path: Optional[str] = None, metadata_path: Optional[str] = None):
        """
        保存向量数据库到磁盘

        Args:
            index_path: FAISS 索引文件路径
            metadata_path: 元数据文件路径
        """
        if not FAISS_AVAILABLE:
            logger.error("FAISS not available")
            return

        idx_path = Path(index_path) if index_path else self.index_path
        meta_path = Path(metadata_path) if metadata_path else self.metadata_path

        if idx_path is None or meta_path is None:
            raise ValueError("Index path or metadata path not provided")

        # 确保目录存在
        idx_path.parent.mkdir(parents=True, exist_ok=True)
        meta_path.parent.mkdir(parents=True, exist_ok=True)

        # 保存 FAISS 索引
        faiss.write_index(self._aircraft_index, str(idx_path.with_suffix('.aircraft.index')))
        faiss.write_index(self._airline_index, str(idx_path.with_suffix('.airline.index')))

        # 保存元数据
        metadata = {
            "records": [record.to_dict() for record in self._records.values()],
            "id_to_index": self._id_to_index,
            "next_index": self._next_index,
            "embedding_dim": self.embedding_dim,
            "metric_type": self.metric_type,
            "timestamp": datetime.now().isoformat()
        }

        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)

        logger.info(f"VectorDatabase saved to {idx_path} and {meta_path}")

    def load(self, index_path: Optional[str] = None, metadata_path: Optional[str] = None):
        """
        从磁盘加载向量数据库

        Args:
            index_path: FAISS 索引文件路径
            metadata_path: 元数据文件路径
        """
        if not FAISS_AVAILABLE:
            logger.error("FAISS not available")
            return

        idx_path = Path(index_path) if index_path else self.index_path
        meta_path = Path(metadata_path) if metadata_path else self.metadata_path

        if idx_path is None or meta_path is None:
            raise ValueError("Index path or metadata path not provided")

        if not idx_path.with_suffix('.aircraft.index').exists():
            raise FileNotFoundError(f"Aircraft index not found: {idx_path.with_suffix('.aircraft.index')}")
        if not idx_path.with_suffix('.airline.index').exists():
            raise FileNotFoundError(f"Airline index not found: {idx_path.with_suffix('.airline.index')}")
        if not meta_path.exists():
            raise FileNotFoundError(f"Metadata not found: {meta_path}")

        # 加载 FAISS 索引
        self._aircraft_index = faiss.read_index(str(idx_path.with_suffix('.aircraft.index')))
        self._airline_index = faiss.read_index(str(idx_path.with_suffix('.airline.index')))

        # 加载元数据
        with open(meta_path, 'r', encoding='utf-8') as f:
            metadata = json.load(f)

        self._records = {r["id"]: VectorRecord.from_dict(r) for r in metadata["records"]}
        self._id_to_index = metadata["id_to_index"]
        self._next_index = metadata["next_index"]
        self.embedding_dim = metadata["embedding_dim"]
        self.metric_type = metadata["metric_type"]

        logger.info(f"VectorDatabase loaded from {idx_path} and {meta_path}")
        logger.info(f"Loaded {len(self._records)} records")

    def get_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        return {
            "num_records": len(self._records),
            "embedding_dim": self.embedding_dim,
            "metric_type": self.metric_type,
            "faiss_available": FAISS_AVAILABLE,
            "aircraft_index_size": self._aircraft_index.ntotal if FAISS_AVAILABLE else 0,
            "airline_index_size": self._airline_index.ntotal if FAISS_AVAILABLE else 0
        }


class NewClassDiscovery:
    """
    新类别发现服务
    使用 HDBSCAN 聚类识别新类别
    """

    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        min_cluster_size: int = 5,
        min_samples: int = 3,
        metric: str = 'euclidean',
        cluster_selection_method: str = 'eom'
    ):
        """
        初始化新类别发现服务

        Args:
            config: HDBSCAN 配置（优先级高于其他参数）
            min_cluster_size: 最小簇大小
            min_samples: 最小样本数
            metric: 距离度量
            cluster_selection_method: 簇选择方法
        """
        self.config = config or {}

        # 使用 config 或直接参数
        self.min_cluster_size = self.config.get('min_cluster_size', min_cluster_size)
        self.min_samples = self.config.get('min_samples', min_samples)
        self.metric = self.config.get('metric', metric)
        self.cluster_selection_method = self.config.get('cluster_selection_method', cluster_selection_method)

        self._clusterer = None
        self._labels = None

        if not HDBSCAN_AVAILABLE:
            logger.warning("HDBSCAN not available, new class discovery will be disabled")
        else:
            logger.info(f"NewClassDiscovery initialized (min_cluster_size={self.min_cluster_size})")

    def discover_new_classes(
        self,
        embeddings: np.ndarray
    ) -> List[int]:
        """
        发现新类别

        Args:
            embeddings: 特征嵌入向量

        Returns:
            新类别样本的索引列表
        """
        if not HDBSCAN_AVAILABLE:
            logger.warning("HDBSCAN not available, returning empty list")
            return []

        if len(embeddings) == 0:
            return []

        logger.info(f"Discovering new classes from {len(embeddings)} embeddings...")

        # 初始化并拟合 HDBSCAN
        self._clusterer = hdbscan.HDBSCAN(
            min_cluster_size=self.min_cluster_size,
            min_samples=self.min_samples,
            metric=self.metric,
            cluster_selection_method=self.cluster_selection_method
        )

        self._clusterer.fit(embeddings)
        self._labels = self._clusterer.labels_

        # 获取异常点索引
        outlier_indices = np.where(self._labels == -1)[0].tolist()

        logger.info(
            f"Found {len(outlier_indices)} potential new class samples "
            f"({len(outlier_indices)/len(embeddings)*100:.1f}%)"
        )

        return outlier_indices

    def get_labels(self) -> Optional[np.ndarray]:
        """获取聚类标签"""
        return self._labels

    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        if self._labels is None:
            return {"available": False}

        n_clusters = len(set(self._labels)) - (1 if -1 in self._labels else 0)
        n_noise = list(self._labels).count(-1)

        return {
            "available": True,
            "total_samples": len(self._labels),
            "n_clusters": n_clusters,
            "n_noise": n_noise,
            "noise_ratio": n_noise / len(self._labels) if len(self._labels) > 0 else 0.0
        }
